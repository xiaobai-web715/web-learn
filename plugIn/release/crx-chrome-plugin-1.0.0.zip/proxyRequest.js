const o = /* @__PURE__ */ Symbol("myXHR"), n = window.XMLHttpRequest;
console.log("开始执行注入逻辑", n[o]);
{
  let e = function() {
    const t = new n();
    return t.addEventListener("readystatechange", function(s) {
      this.readyState === 4 && console.log("我是请求的url以及响应资源", this, this.responseURL, this.response);
    }), t;
  };
  console.log("执行请求代理逻辑"), e[o] = !0, Reflect.ownKeys(window.XMLHttpRequest).forEach((t) => {
    console.log("获取属性的目标信息", t, Object.getOwnPropertyDescriptor(window.XMLHttpRequest, t)), Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(window.XMLHttpRequest, t));
  }), window.XMLHttpRequest = e;
}
//# sourceMappingURL=proxyRequest.js.map
