const n = /* @__PURE__ */ Symbol("myXHR");
function r() {
  const o = window.XMLHttpRequest;
  {
    let e = function() {
      const t = new o();
      return t.addEventListener("readystatechange", function(s) {
        this.readyState === 4 && console.log("我是请求的url以及响应资源", this, this.responseURL, this.response);
      }), t;
    };
    e[n] = !0, Reflect.ownKeys(window.XMLHttpRequest).forEach((t) => {
      console.log("获取属性的目标信息", t, Object.getOwnPropertyDescriptor(window.XMLHttpRequest, t)), Object.defineProperty(e, t, Object.getOwnPropertyDescriptor(window.XMLHttpRequest, t));
    }), window.XMLHttpRequest = e;
  }
}
r();
//# sourceMappingURL=proxyRequest.js.map
